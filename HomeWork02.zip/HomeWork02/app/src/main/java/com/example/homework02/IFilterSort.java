package com.example.homework02;

import java.util.List;

public interface IFilterSort {
    void applyConfig(List<DataServices.User> users, Config config);
}
